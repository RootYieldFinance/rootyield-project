require('dotenv').config();
const express = require('express');
const cors = require('cors');
const Web3 = require('web3');
const { abi } = require('./RootYieldABI.json');

const app = express();
const router = express.Router();

// Configuração do Web3
const web3 = new Web3(process.env.INFURA_URL);
const contractAddress = process.env.CONTRACT_ADDRESS;
const contract = new web3.eth.Contract(abi, contractAddress);

// Middleware
router.use(cors());
router.use(express.json());

// Rotas de dados
router.get('/token-data', async (req, res) => {
    try {
        const totalSupply = await contract.methods.totalSupply().call();
        const totalStaked = await contract.methods.totalStaked().call();
        const totalBurned = await contract.methods.totalBurned().call();
        const tokenPrice = await contract.methods.getTokenPrice().call();

        res.json({
            totalSupply: Web3.utils.fromWei(totalSupply, 'ether'),
            totalStaked: Web3.utils.fromWei(totalStaked, 'ether'),
            totalBurned: Web3.utils.fromWei(totalBurned, 'ether'),
            tokenPrice
        });
    } catch (error) {
        res.status(500).json({ error: 'Erro ao obter dados do token' });
    }
});

// Rotas administrativas
router.post('/admin/burn-tokens', async (req, res) => {
    try {
        const { authToken, amount, fromAddress } = req.body;
        if (!authToken || authToken !== process.env.ADMIN_TOKEN) {
            return res.status(401).json({ error: 'Não autorizado' });
        }
        
        const amountWei = Web3.utils.toWei(amount.toString(), 'ether');
        
        const adminAccount = web3.eth.accounts.privateKeyToAccount(process.env.ADMIN_PRIVATE_KEY);
        const txData = contract.methods.burnTokens(fromAddress, amountWei).encodeABI();
        
        const tx = {
            from: adminAccount.address,
            to: contractAddress,
            data: txData,
            gas: 500000
        };
        
        const signedTx = await adminAccount.signTransaction(tx);
        const receipt = await web3.eth.sendSignedTransaction(signedTx.rawTransaction);
        
        res.json({ success: true, txHash: receipt.transactionHash });
    } catch (error) {
        res.status(500).json({ error: 'Erro ao queimar tokens' });
    }
});

// Exportar como função serverless do Vercel
module.exports = router;