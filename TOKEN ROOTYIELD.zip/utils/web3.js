import Web3 from 'web3';

// Configuração do Web3
let web3;
let contract;
let contractABI = []; // Preencher com o ABI real

// Inicializar Web3
export async function initWeb3() {
    if (window.ethereum) {
        try {
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            web3 = new Web3(window.ethereum);
            return true;
        } catch (error) {
            console.error("Erro ao conectar carteira:", error);
            return false;
        }
    } else {
        console.error("MetaMask não instalado!");
        return false;
    }
}

// Inicializar contrato
export function initContract(contractAddress) {
    if (!web3) return null;
    contract = new web3.eth.Contract(contractABI, contractAddress);
    return contract;
}

// Obter conta atual
export async function getCurrentAccount() {
    if (!web3) return null;
    const accounts = await web3.eth.getAccounts();
    return accounts[0];
}

// Obter saldo do token
export async function getTokenBalance(account) {
    if (!contract || !account) return 0;
    const balance = await contract.methods.balanceOf(account).call();
    return web3.utils.fromWei(balance, 'ether');
}