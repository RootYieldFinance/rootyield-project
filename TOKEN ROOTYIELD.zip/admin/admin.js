// Inicializar gráficos
document.addEventListener('DOMContentLoaded', () => {
    // Gráfico de preço
    const priceCtx = document.getElementById('priceChart').getContext('2d');
    const priceChart = new Chart(priceCtx, {
        type: 'line',
        data: {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
            datasets: [{
                label: 'RY Price (USD)',
                data: [0.05, 0.07, 0.09, 0.12, 0.11, 0.13],
                borderColor: '#4361ee',
                backgroundColor: 'rgba(67, 97, 238, 0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });

    // Gráfico de stakers
    const stakersCtx = document.getElementById('stakersChart').getContext('2d');
    const stakersChart = new Chart(stakersCtx, {
        type: 'bar',
        data: {
            labels: ['Bronze', 'Silver', 'Gold'],
            datasets: [{
                label: 'Stakers',
                data: [8420, 3156, 1024],
                backgroundColor: [
                    'rgba(205, 127, 50, 0.7)',
                    'rgba(192, 192, 192, 0.7)',
                    'rgba(255, 215, 0, 0.7)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                }
            }
        }
    });
});